package com.projetobebaagua;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoBebaAguaApplicationTests {

	@Test
	void contextLoads() {
	}

}
