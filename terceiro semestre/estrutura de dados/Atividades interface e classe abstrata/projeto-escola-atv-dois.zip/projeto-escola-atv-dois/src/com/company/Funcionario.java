package com.company;

public interface Funcionario {

    public Double getValorBonus();
}


